/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dto;

import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BorrowingDto {
    private String transactionID;
    private String memberID;
    private String borrowDate;
    
     private ArrayList<BorrowingDetailDto>borrowingDetailDtos;

    public BorrowingDto() {
    }

    public BorrowingDto(String transactionID, String memberID, String borrowDate, ArrayList<BorrowingDetailDto> borrowingDetailDtos) {
        this.transactionID = transactionID;
        this.memberID = memberID;
        this.borrowDate = borrowDate;
        this.borrowingDetailDtos = borrowingDetailDtos;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * @param transactionID the transactionID to set
     */
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the memberID
     */
    public String getMemberID() {
        return memberID;
    }

    /**
     * @param memberID the memberID to set
     */
    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    /**
     * @return the borrowDate
     */
    public String getBorrowDate() {
        return borrowDate;
    }

    /**
     * @param borrowDate the borrowDate to set
     */
    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    /**
     * @return the borrowingDetailDtos
     */
    public ArrayList<BorrowingDetailDto> getBorrowingDetailDtos() {
        return borrowingDetailDtos;
    }

    /**
     * @param borrowingDetailDtos the borrowingDetailDtos to set
     */
    public void setBorrowingDetailDtos(ArrayList<BorrowingDetailDto> borrowingDetailDtos) {
        this.borrowingDetailDtos = borrowingDetailDtos;
    }

    @Override
    public String toString() {
        return "BorrowingDto{" + "transactionID=" + transactionID + ", memberID=" + memberID + ", borrowDate=" + borrowDate + ", borrowingDetailDtos=" + borrowingDetailDtos + '}';
    }

  
    
     
     
}
