/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dto;

/**
 *
 * @author Admin
 */
public class BooksDto {
    private String bookID;
    private String title;
    private String author;
    private String  categoryID;
    private int CopiesAvailable;
    private double price;
    private String medium;
    private String publisher;
    private String firstAuthor;
    private int copiesInHand;

    public BooksDto(String bookID, String title, String author, String categoryID, int CopiesAvailable, double price, String medium, String publisher, String firstAuthor, int copiesInHand) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.categoryID = categoryID;
        this.CopiesAvailable = CopiesAvailable;
        this.price = price;
        this.medium = medium;
        this.publisher = publisher;
        this.firstAuthor = firstAuthor;
        this.copiesInHand = copiesInHand;
    }

    public BooksDto() {
    }

    /**
     * @return the bookID
     */
    public String getBookID() {
        return bookID;
    }

    /**
     * @param bookID the bookID to set
     */
    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return the categoryID
     */
    public String getCategoryID() {
        return categoryID;
    }

    /**
     * @param categoryID the categoryID to set
     */
    public void setCategoryID(String categoryID) {
        this.categoryID = categoryID;
    }

    /**
     * @return the CopiesAvailable
     */
    public int getCopiesAvailable() {
        return CopiesAvailable;
    }

    /**
     * @param CopiesAvailable the CopiesAvailable to set
     */
    public void setCopiesAvailable(int CopiesAvailable) {
        this.CopiesAvailable = CopiesAvailable;
    }

    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return the medium
     */
    public String getMedium() {
        return medium;
    }

    /**
     * @param medium the medium to set
     */
    public void setMedium(String medium) {
        this.medium = medium;
    }

    /**
     * @return the publisher
     */
    public String getPublisher() {
        return publisher;
    }

    /**
     * @param publisher the publisher to set
     */
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    /**
     * @return the firstAuthor
     */
    public String getFirstAuthor() {
        return firstAuthor;
    }

    /**
     * @param firstAuthor the firstAuthor to set
     */
    public void setFirstAuthor(String firstAuthor) {
        this.firstAuthor = firstAuthor;
    }

    /**
     * @return the copiesInHand
     */
    public int getCopiesInHand() {
        return copiesInHand;
    }

    /**
     * @param copiesInHand the copiesInHand to set
     */
    public void setCopiesInHand(int copiesInHand) {
        this.copiesInHand = copiesInHand;
    }

    @Override
    public String toString() {
        return "BooksDto{" + "bookID=" + bookID + ", title=" + title + ", author=" + author + ", categoryID=" + categoryID + ", CopiesAvailable=" + CopiesAvailable + ", price=" + price + ", medium=" + medium + ", publisher=" + publisher + ", firstAuthor=" + firstAuthor + ", copiesInHand=" + copiesInHand + '}';
    }

    
    
}
