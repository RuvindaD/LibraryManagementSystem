/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.entity;

/**
 *
 * @author Admin
 */
public class MembersEntity {
    private String memberID;
    private String title;
    private String firstName;
    private String lastName;
    private String dOB;
    private String address;
    private String phoneNumber;
    private String email;
    private String membershipstartDate;

    public MembersEntity(String memberID, String title, String firstName, String lastName, String dOB, String address, String phoneNumber, String email, String membershipstartDate) {
        this.memberID = memberID;
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dOB = dOB;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.membershipstartDate = membershipstartDate;
    }

    /**
     * @return the memberID
     */
    public String getMemberID() {
        return memberID;
    }

    /**
     * @param memberID the memberID to set
     */
    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the dOB
     */
    public String getdOB() {
        return dOB;
    }

    /**
     * @param dOB the dOB to set
     */
    public void setdOB(String dOB) {
        this.dOB = dOB;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the membershipstartDate
     */
    public String getMembershipstartDate() {
        return membershipstartDate;
    }

    /**
     * @param membershipstartDate the membershipstartDate to set
     */
    public void setMembershipstartDate(String membershipstartDate) {
        this.membershipstartDate = membershipstartDate;
    }

    @Override
    public String toString() {
        return "MembersEntity{" + "memberID=" + memberID + ", title=" + title + ", firstName=" + firstName + ", lastName=" + lastName + ", dOB=" + dOB + ", address=" + address + ", phoneNumber=" + phoneNumber + ", email=" + email + ", membershipstartDate=" + membershipstartDate + '}';
    }
    
    
}
