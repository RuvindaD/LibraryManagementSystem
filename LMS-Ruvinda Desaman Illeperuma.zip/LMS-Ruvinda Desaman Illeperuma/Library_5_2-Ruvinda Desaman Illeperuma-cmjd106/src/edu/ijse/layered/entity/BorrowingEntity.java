/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.entity;

/**
 *
 * @author Admin
 */
public class BorrowingEntity {
    private String transactionID;
    private String memberID;
    private String borrowDate;

    public BorrowingEntity() {
    }

    public BorrowingEntity(String transactionID, String memberID, String borrowDate) {
        this.transactionID = transactionID;
        this.memberID = memberID;
        this.borrowDate = borrowDate;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * @param transactionID the transactionID to set
     */
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the memberID
     */
    public String getMemberID() {
        return memberID;
    }

    /**
     * @param memberID the memberID to set
     */
    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    /**
     * @return the borrowDate
     */
    public String getBorrowDate() {
        return borrowDate;
    }

    /**
     * @param borrowDate the borrowDate to set
     */
    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    @Override
    public String toString() {
        return "BorrowingEntity{" + "transactionID=" + transactionID + ", memberID=" + memberID + ", borrowDate=" + borrowDate + '}';
    }

    
   
    
}
