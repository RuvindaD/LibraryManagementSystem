/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.entity;

/**
 *
 * @author Admin
 */
public class BorrowingDetailEntity {
    private String transactionID;
    private String bookID;
    private String dueDate;
    private int Quantity;

    public BorrowingDetailEntity() {
    }

    public BorrowingDetailEntity(String transactionID, String bookID, String dueDate, int Quantity) {
        this.transactionID = transactionID;
        this.bookID = bookID;
        this.dueDate = dueDate;
        this.Quantity = Quantity;
    }

    /**
     * @return the transactionID
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * @param transactionID the transactionID to set
     */
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * @return the bookID
     */
    public String getBookID() {
        return bookID;
    }

    /**
     * @param bookID the bookID to set
     */
    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    /**
     * @return the dueDate
     */
    public String getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate the dueDate to set
     */
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the Quantity
     */
    public int getQuantity() {
        return Quantity;
    }

    /**
     * @param Quantity the Quantity to set
     */
    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    @Override
    public String toString() {
        return "BorrowingDetailEntity{" + "transactionID=" + transactionID + ", bookID=" + bookID + ", dueDate=" + dueDate + ", Quantity=" + Quantity + '}';
    }

    

    
    
}
