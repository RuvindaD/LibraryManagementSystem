/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.BooksDao;
import edu.ijse.layered.entity.BooksEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BooksDaoImpl implements BooksDao {

    @Override
    public boolean create(BooksEntity t) throws Exception {
        return CrudUtil.executeUpdate("INSERT INTO books VALUES(?,?,?,?,?,?,?,?,?,?)",t.getBookID(),t.getTitle(),t.getAuthor(),t.getCategoryID(),t.getCopiesAvailable(),t.getPrice(),t.getMedium(),t.getPublisher(),t.getFirstAuthor(),t.getCopiesInHand());
    }

    @Override
    public boolean update(BooksEntity t) throws Exception {
        return CrudUtil.executeUpdate( "UPDATE BOOKS SET Title=?,Author=?,CategoryID=?,CopiesAvailable=?, Price=?,Medium=?, Publisher=?, FirstAuthor=?, CopiesInHand=? WHERE  BookID=? ",
                t.getTitle(),t.getAuthor(),t.getCategoryID(),t.getCopiesAvailable(),t.getPrice(),t.getMedium(),t.getPublisher(),t.getFirstAuthor(),t.getCopiesInHand(),t.getBookID());
    }
    

    @Override
    public boolean delete(String id) throws Exception {
        return CrudUtil.executeUpdate("DELETE FROM books WHERE BookID=? ",id);
    }

    @Override
    public BooksEntity get (String id)throws Exception{
     ResultSet rst=CrudUtil.executeQuery("SELECT * FROM books WHERE BookID=?",id);
        if(rst.next()){
            BooksEntity entity= new  BooksEntity(rst.getString("BookID"),rst.getString("Title"),rst.getString("Author"),rst.getString("CategoryID"),rst.getInt("CopiesAvailable"),rst.getDouble("Price"),rst.getString("Medium"),rst.getString("Publisher"),rst.getString("FirstAuthor"),rst.getInt("CopiesInHand"));
            return entity;
            }
         return null;
    }
    @Override
    public ArrayList<BooksEntity> getAll() throws Exception {
        ArrayList<BooksEntity> booksEntities= new ArrayList<>();
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM books");
       while(rst.next()){
            BooksEntity entity= new  BooksEntity(rst.getString("BookID"),rst.getString("Title"),rst.getString("Author"),rst.getString("CategoryID"),rst.getInt("CopiesAvailable"),rst.getDouble("Price"),rst.getString("Medium"),rst.getString("Publisher"),rst.getString("FirstAuthor"),rst.getInt("CopiesInHand"));
            booksEntities.add(entity);
            }
         return booksEntities;
    }
 }
    

