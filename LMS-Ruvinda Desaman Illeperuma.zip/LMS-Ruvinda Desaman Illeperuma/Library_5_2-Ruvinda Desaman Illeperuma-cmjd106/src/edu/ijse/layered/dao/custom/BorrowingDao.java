/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.ijse.layered.dao.custom;

import edu.ijse.layered.dao.CrudDao;
import edu.ijse.layered.entity.BorrowingEntity;

/**
 *
 * @author Admin
 */
public interface BorrowingDao extends CrudDao<BorrowingEntity, String> {
    
}
