/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.BorrowingDao;
import edu.ijse.layered.entity.BorrowingEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BorrowingDaoImpl implements BorrowingDao  {

    @Override
    public boolean create(BorrowingEntity t) throws Exception {
       return CrudUtil.executeUpdate("INSERT INTO borrowing VALUES(?,?,?)",t.getTransactionID(),t.getMemberID(),t.getBorrowDate());
    }

    @Override
    public boolean update(BorrowingEntity t) throws Exception {
        return CrudUtil.executeUpdate( "UPDATE BORROWING SET MemberID=?,BorrowDate=? WHERE TransactionID=? ",
   t.getBorrowDate(),t.getMemberID(),t.getTransactionID());
    }

    @Override
    public boolean delete(String id) throws Exception {
       return CrudUtil.executeUpdate("DELETE FROM borrowing WHERE TransactionID=? ",id);
    }

    @Override
    public BorrowingEntity get(String id) throws Exception {
      ResultSet rst=CrudUtil.executeQuery("SELECT * FROM borrowing WHERE TransactionID=?",id);
        if(rst.next()){
            BorrowingEntity entity= new  BorrowingEntity(rst.getString("TransactionID"),rst.getString("MemberID"),rst.getString("BorrowDate")); 
            return entity;
    }
        return null;
    }


    @Override
    public ArrayList<BorrowingEntity> getAll() throws Exception {
      ArrayList<BorrowingEntity> borrowingEntities= new ArrayList<>();
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM borrowing");
       while(rst.next()){
            BorrowingEntity entity= new BorrowingEntity(rst.getString("TransactionID"),rst.getString("MemberID"),rst.getString("BorrowDate")); 
            borrowingEntities.add(entity);
        }
    return borrowingEntities;
    }
 
}
