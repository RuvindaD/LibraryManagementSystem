/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.TransactionsDao;
import edu.ijse.layered.entity.BooksEntity;
import edu.ijse.layered.entity.TransactionsEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class TransactionsDaoImpl implements TransactionsDao  {

    @Override
    public boolean create(TransactionsEntity t) throws Exception {
        return CrudUtil.executeUpdate("INSERT INTO transactions VALUES(?,?,?,?,?,?,?)",t.getTransactionID(),t.getMemberID(),t.getBookID(),t.getBorrowDate(),t.getDueDate(),t.getReturnDate(),t.getFineAmount());
    }

    @Override
    public boolean update(TransactionsEntity t) throws Exception {
         return CrudUtil.executeUpdate( "UPDATE TRANSACTIONS SET MemberID=?, BookID=?, BorrowDate=?, DueDate=?, ReturnDate=?, FineAmount=? WHERE TransactionID=? ",
                t.getMemberID(),t.getBookID(),t.getBorrowDate(),t.getDueDate(),t.getReturnDate(),t.getFineAmount(),t.getTransactionID());
    }

    @Override
    public boolean delete(String id) throws Exception {
        return CrudUtil.executeUpdate("DELETE FROM transactions WHERE TransactionID=? ",id);
    }

    @Override
    public TransactionsEntity get(String id) throws Exception {
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM transactions WHERE TransactionID=? ",id);
        if(rst.next()){
            TransactionsEntity entity= new TransactionsEntity(rst.getString("TransactionID"),rst.getString("MemberID"),rst.getString("BookID"),rst.getString("BorrowDate"),rst.getString("DueDate"),rst.getString("ReturnDate"),rst.getDouble("FineAmount"));
            return entity;
            }
         return null;
    }
    @Override
    public ArrayList<TransactionsEntity> getAll() throws Exception {
        ArrayList<TransactionsEntity> transactionsEntities= new ArrayList<>();
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM transactions");
       while(rst.next()){
            TransactionsEntity entity= new TransactionsEntity(rst.getString("TransactionID"),rst.getString("MemberID"),rst.getString("BookID"),rst.getString("BorrowDate"),rst.getString("DueDate"),rst.getString("ReturnDate"),rst.getDouble("FineAmount"));
           transactionsEntities.add(entity);
            }
         return transactionsEntities;
    }
}
