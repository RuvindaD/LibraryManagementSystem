/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.BorrowingDetailDao;
import edu.ijse.layered.entity.BorrowingDetailEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BorrowingDetailDaoImpl implements BorrowingDetailDao {

    @Override
    public boolean create(BorrowingDetailEntity t) throws Exception {
        return  CrudUtil.executeUpdate("INSERT INTO borrowingdetail VALUES(?,?,?,?)",t.getTransactionID(),t.getBookID(),t.getDueDate(),t.getQuantity());
    }

    @Override
    public boolean update(BorrowingDetailEntity t) throws Exception {
        return CrudUtil.executeUpdate( "UPDATE BORROWING_DETAIL SET BookID=?,DueDate=?,Quantity=? WHERE TransactionID=? ",
   t.getBookID(),t.getDueDate(),t.getQuantity(),t.getTransactionID());
    }

    @Override
    public boolean delete(Object id) throws Exception {
          return CrudUtil.executeUpdate("DELETE FROM borrowingdetail WHERE TransactionID=? ",id);
    }

    @Override
    public BorrowingDetailEntity get(Object id) throws Exception {
        ResultSet rst=CrudUtil.executeQuery("SELECT * FROM borrowingdetail WHERE TransactionID=?",id);
        if(rst.next()){
            BorrowingDetailEntity entity= new  BorrowingDetailEntity(rst.getString("TransactionID"),rst.getString("BookID"),rst.getString("DueDate"),rst.getInt("Quantity")); 
            return entity;
    }
        return null;
    }

    @Override
   
    public ArrayList<BorrowingDetailEntity> getAll() throws Exception {
        ArrayList<BorrowingDetailEntity> borrowingdetailEntities = new ArrayList<>();
        ResultSet rst = CrudUtil.executeQuery("SELECT * FROM borrowingdetail");
        while (rst.next()) {
            BorrowingDetailEntity entity = new BorrowingDetailEntity(rst.getString("TransactionID"), rst.getString("BookID"), rst.getString("DueDate"), rst.getInt("Quantity"));
            borrowingdetailEntities.add(entity);
        }
        return borrowingdetailEntities;
    }
}
