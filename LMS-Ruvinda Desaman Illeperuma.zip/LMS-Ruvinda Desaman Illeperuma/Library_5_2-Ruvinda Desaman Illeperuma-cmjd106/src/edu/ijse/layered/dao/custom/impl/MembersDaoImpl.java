/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.MembersDao;
import edu.ijse.layered.entity.MembersEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class MembersDaoImpl implements MembersDao{

    @Override
    public boolean create(MembersEntity t) throws Exception {
        return CrudUtil.executeUpdate("INSERT INTO  members VALUES(?,?,?,?,?,?,?,?,?)",t.getMemberID(),t.getTitle(),t.getFirstName(),t.getLastName(),t.getdOB(),t.getAddress(),t.getPhoneNumber(),t.getEmail(),t.getMembershipstartDate());
    }

    @Override
    public boolean update(MembersEntity t) throws Exception {
        return CrudUtil.executeUpdate( "UPDATE MEMBERS SET Title=?, FirstName=?, LastName=?, DOB=?, Address=?, PhoneNumber=?, Email=?, MembershipStartDate=? WHERE  MemberID=?",
                t.getTitle(),t.getFirstName(),t.getLastName(),t.getdOB(),t.getAddress(),t.getPhoneNumber(),t.getEmail(),t.getMembershipstartDate(),t.getMemberID());
    }

    @Override
    public boolean delete(String id) throws Exception {
        return CrudUtil.executeUpdate("DELETE FROM  members WHERE MemberID=?",id);
    }

    @Override
    public MembersEntity get(String id) throws Exception {
        ResultSet rst=CrudUtil.executeQuery("SELECT * FROM  members WHERE MemberID=?",id);
        if(rst.next()){
            MembersEntity entity= new  MembersEntity(rst.getString("MemberID"),rst.getString("Title"),rst.getString("FirstName"),rst.getString("LastName"),rst.getString("DOB"),rst.getString("Address"),rst.getString("PhoneNumber"),rst.getString("Email"),rst.getString("MembershipStartDate"));
            return entity;
            }
         return null;
    }

    @Override
    public ArrayList<MembersEntity> getAll() throws Exception {
        ArrayList<MembersEntity>  membersEntities= new ArrayList<>();
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM  members");
       while(rst.next()){
            MembersEntity entity= new  MembersEntity(rst.getString("MemberID"),rst.getString("Title"),rst.getString("FirstName"),rst.getString("LastName"),rst.getString("DOB"),rst.getString("Address"),rst.getString("PhoneNumber"),rst.getString("Email"),rst.getString("MembershipStartDate"));
             membersEntities.add(entity);
            }
         return  membersEntities;
    }
    
}
  

