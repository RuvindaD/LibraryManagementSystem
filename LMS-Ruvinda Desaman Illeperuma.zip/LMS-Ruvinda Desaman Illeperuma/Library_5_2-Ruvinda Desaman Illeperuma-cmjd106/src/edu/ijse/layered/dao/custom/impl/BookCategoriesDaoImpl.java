/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.dao.custom.impl;

import edu.ijse.layered.dao.CrudUtil;
import edu.ijse.layered.dao.custom.BookCategoriesDao;
import edu.ijse.layered.entity.BookCategoriesEntity;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BookCategoriesDaoImpl implements BookCategoriesDao{

    @Override
    public boolean create(BookCategoriesEntity t) throws Exception {
        return CrudUtil.executeUpdate("INSERT INTO bookcategories VALUES(?,?,?)",t.getCategoryID(),t.getCategoryName(),t.getCategoryDescription());
    }

    @Override
    public boolean update(BookCategoriesEntity t) throws Exception {
   return CrudUtil.executeUpdate( "UPDATE BOOKCATEGORIES SET CategoryName=?,CategoryDescription=? WHERE CategoryID=? ",
   t.getCategoryName(),t.getCategoryDescription(),t.getCategoryID());
    }

    @Override
    public boolean delete(String id) throws Exception {
      return CrudUtil.executeUpdate("DELETE FROM bookcategories WHERE CategoryID=? ",id);  
        
    }

    @Override
    public BookCategoriesEntity get(String id) throws Exception {
        ResultSet rst=CrudUtil.executeQuery("SELECT * FROM bookcategories WHERE CategoryID=?",id);
        if(rst.next()){
            BookCategoriesEntity entity= new  BookCategoriesEntity(rst.getString("CategoryID"),rst.getString("CategoryName"),rst.getString("CategoryDescription")); 
            return entity;
    }
        return null;
    }

    @Override
    public ArrayList<BookCategoriesEntity> getAll() throws Exception {
       ArrayList<BookCategoriesEntity> bookcategoriesEntities= new ArrayList<>();
       ResultSet rst=CrudUtil.executeQuery("SELECT * FROM bookcategories");
       while(rst.next()){
            BookCategoriesEntity entity= new BookCategoriesEntity(rst.getString("CategoryID"),rst.getString("CategoryName"),rst.getString("CategoryDescription")); 
            bookcategoriesEntities.add(entity);
        }
    return bookcategoriesEntities; 
    }
}
