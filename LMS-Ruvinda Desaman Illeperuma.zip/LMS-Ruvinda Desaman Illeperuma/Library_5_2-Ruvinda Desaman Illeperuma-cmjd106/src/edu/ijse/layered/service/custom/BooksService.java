/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.ijse.layered.service.custom;

import edu.ijse.layered.dto.BooksDto;
import edu.ijse.layered.service.SuperService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public interface BooksService extends SuperService{
   String save(BooksDto booksDto) throws Exception;
   String update(BooksDto booksDto) throws Exception;
   String delete(String BookID) throws Exception;
   BooksDto get(String BookID)throws Exception;
   ArrayList<BooksDto> getAll() throws Exception;
}
    

