/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.service.custom.impl;

import edu.ijse.layered.dao.DaoFactory;
import edu.ijse.layered.dao.custom.MembersDao;
import edu.ijse.layered.dto.MembersDto;
import edu.ijse.layered.entity.MembersEntity;
import edu.ijse.layered.service.custom.MembersService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class MembersServiceImpl implements MembersService {
    
    private MembersDao membersDao =(MembersDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.MEMBERS);

    @Override
    public String save(MembersDto membersDto) throws Exception {
        MembersEntity entity= getMembersEntity(membersDto);
       
        return membersDao.create(entity) ? "Success" :"Fail";
    }

    @Override
    public String update(MembersDto membersDto) throws Exception {
        MembersEntity entity=getMembersEntity(membersDto);
        return membersDao.update(entity) ? "Success" :"Fail";
    }

    @Override
    public String delete(String MemberID) throws Exception {
        return membersDao.delete(MemberID)? "Success" :"Fail";
    }

    @Override
    public MembersDto get(String MemberID) throws Exception {
      MembersEntity entity= membersDao.get(MemberID);
      if(entity!=null){
            return getMembersDto(entity);
        }
        return null;
    }

    @Override
    public ArrayList<MembersDto> getAll() throws Exception {
         ArrayList<MembersEntity> membersEntitys=membersDao.getAll();
       if(membersEntitys != null && !membersEntitys.isEmpty()){
           ArrayList<MembersDto> membersDtos= new ArrayList<>();
           
           for(MembersEntity membersEntity : membersEntitys){
               membersDtos.add(getMembersDto(membersEntity));
           }
           return membersDtos;
       }
       return null;
    }
    
     private MembersEntity getMembersEntity(MembersDto membersDto){
       return  new MembersEntity( 
                membersDto.getMemberID(),
                 membersDto.getTitle(),
                 membersDto.getFirstName(),
                 membersDto.getLastName(),
                membersDto.getdOB(), 
                membersDto.getAddress(),
                 membersDto.getPhoneNumber(),
                 membersDto.getEmail(),
                 membersDto.getMembershipstartDate() );
                 
               
               }

    private MembersDto getMembersDto(MembersEntity entity) {
       return new MembersDto(
                 entity.getMemberID(),
                  entity.getTitle(),
                  entity.getFirstName(),
                  entity.getLastName(),
                 entity.getdOB(),
                entity.getAddress(),
                  entity.getPhoneNumber(),
                  entity.getEmail(),
                  entity.getMembershipstartDate() );
                 
       
       
    }
    
}
