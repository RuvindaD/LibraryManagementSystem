/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.service.custom.impl;

import edu.ijse.layered.dao.DaoFactory;
import edu.ijse.layered.dao.custom.BooksDao;
import edu.ijse.layered.dao.custom.BorrowingDao;
import edu.ijse.layered.dao.custom.BorrowingDetailDao;
import edu.ijse.layered.db.DBConnection;
import edu.ijse.layered.dto.BorrowingDto;
import edu.ijse.layered.dto.BorrowingDetailDto;
import edu.ijse.layered.entity.BooksEntity;
import edu.ijse.layered.entity.BorrowingDetailEntity;
import edu.ijse.layered.entity.BorrowingEntity;
import edu.ijse.layered.service.custom.BorrowingService;
import java.sql.Connection;

/**
 *
 * @author Admin
 */
public class BorrowingServiceImpl implements BorrowingService {
    private BorrowingDao borrowingDao = (BorrowingDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.BORROWING);
    private BorrowingDetailDao borrowingDetailDao = (BorrowingDetailDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.BORROWING_DETAIL);
    private BooksDao booksDao = (BooksDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.BOOKS);

    @Override
    public String placeBorrowing(BorrowingDto borrowingDto) throws Exception {
        Connection connection = DBConnection.getInstance().getConnection();

        try {
            connection.setAutoCommit(false);
            BorrowingEntity borrowingEntity = new BorrowingEntity(borrowingDto.getTransactionID(), borrowingDto.getMemberID(), borrowingDto.getBorrowDate());

            if (borrowingDao.create(borrowingEntity)) {
                boolean isBorrowingDetailSaved = true;

                for (BorrowingDetailDto borrowingDetailDto : borrowingDto.getBorrowingDetailDtos()) {
                    BorrowingDetailEntity borrowingDetailEntity = new BorrowingDetailEntity(borrowingDto.getTransactionID(), borrowingDetailDto.getBookID(), borrowingDetailDto.getDueDate(), borrowingDetailDto.getQuantity());

                    if (!borrowingDetailDao.create(borrowingDetailEntity)) {
                        isBorrowingDetailSaved = false;
                        //break;
                    }
                }

                if (isBorrowingDetailSaved) {
                    boolean isBooksUpdated = true;

                    for (BorrowingDetailDto borrowingDetailDto : borrowingDto.getBorrowingDetailDtos()) {
                        BooksEntity booksEntity = booksDao.get(borrowingDetailDto.getBookID());

                        if (booksEntity != null) {
                            booksEntity.setCopiesInHand(booksEntity.getCopiesInHand() - borrowingDetailDto.getQuantity());

                            if (!booksDao.update(booksEntity)) {
                                isBooksUpdated = false;
                                //break;
//                            }
//                        } else {
//                            isBooksUpdated = false;
//                            break;
                        }
                    }
                }        

                    if (isBooksUpdated) {
                        connection.commit();
                        return "Success";
                    } else {
                        connection.rollback();
                        return "Book Update Error";
                    }
                } else {
                    connection.rollback();
                    return "Borrowing Detail Save Error";
                }
            } else {
                connection.rollback();
                return "Borrowing Save Error";
            }
        } catch (Exception e) {
            connection.rollback();
           e.printStackTrace();
           throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }
}
