/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.ijse.layered.service.custom;

import edu.ijse.layered.dto.BorrowingDto;
import edu.ijse.layered.service.SuperService;

/**
 *
 * @author Admin
 */
public interface BorrowingService extends SuperService {
    public String placeBorrowing(BorrowingDto borrowingDto)throws Exception;
    
}
