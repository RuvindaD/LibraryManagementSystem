/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.ijse.layered.service.custom;

import edu.ijse.layered.dto.BookCategoriesDto;
import edu.ijse.layered.service.SuperService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public interface BookCategoriesService extends SuperService{
   String save(BookCategoriesDto bookcategoriesDto) throws Exception;
   String update(BookCategoriesDto bookcategoriesDto) throws Exception;
   String delete(String CategoryID) throws Exception;
   BookCategoriesDto get(String CategoryID)throws Exception;
   ArrayList<BookCategoriesDto> getAll() throws Exception;
}
