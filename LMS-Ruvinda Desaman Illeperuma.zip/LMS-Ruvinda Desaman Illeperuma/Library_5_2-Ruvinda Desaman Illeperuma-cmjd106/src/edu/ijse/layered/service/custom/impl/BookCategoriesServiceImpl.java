/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.service.custom.impl;

import edu.ijse.layered.dao.DaoFactory;
import edu.ijse.layered.dao.custom.BookCategoriesDao;
import edu.ijse.layered.dto.BookCategoriesDto;
import edu.ijse.layered.entity.BookCategoriesEntity;
import edu.ijse.layered.service.custom.BookCategoriesService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BookCategoriesServiceImpl implements BookCategoriesService{
    
    private BookCategoriesDao bookcategoriesDao =(BookCategoriesDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.BOOKCATEGORIES);
    
    @Override
    public BookCategoriesDto get(String CategoryID) throws Exception {
        BookCategoriesEntity entity= bookcategoriesDao.get(CategoryID);
        if(entity!=null){
            return getBookCategoriesDto(entity);
        }
        return null;
    }

    @Override
    public String save(BookCategoriesDto bookcategoriesDto) throws Exception {
        BookCategoriesEntity entity=getBookCategoriesEntity(bookcategoriesDto);
        return bookcategoriesDao.create(entity) ? "Success" :"Fail";
    }

    @Override
    public String update(BookCategoriesDto bookcategoriesDto) throws Exception {
        BookCategoriesEntity entity=getBookCategoriesEntity(bookcategoriesDto);
        return bookcategoriesDao.update(entity) ? "Success" :"Fail";
    }

    @Override
    public String delete(String CategoryID) throws Exception {
        return bookcategoriesDao.delete(CategoryID)? "Success" :"Fail";
    }

    
    @Override
    public ArrayList<BookCategoriesDto> getAll() throws Exception {
       ArrayList<BookCategoriesEntity> bookcategoriesEntitys=bookcategoriesDao.getAll();
       if(bookcategoriesEntitys != null && !bookcategoriesEntitys.isEmpty()){
           ArrayList<BookCategoriesDto> bookcategoriesDtos= new ArrayList<>();
           
           for(BookCategoriesEntity bookcategoriesEntity : bookcategoriesEntitys){
               bookcategoriesDtos.add(getBookCategoriesDto(bookcategoriesEntity));
           }
           return bookcategoriesDtos;
       }
       return null;
    }
    private BookCategoriesEntity getBookCategoriesEntity(BookCategoriesDto bookcategoriesDto){
       return  new BookCategoriesEntity(bookcategoriesDto.getCategoryID(), 
                bookcategoriesDto.getCategoryName(), 
                bookcategoriesDto.getCategoryDescription());
    }
    
    private BookCategoriesDto getBookCategoriesDto(BookCategoriesEntity entity){
       return  new BookCategoriesDto (entity.getCategoryID(), 
                entity.getCategoryName(), 
                entity.getCategoryDescription());
    }
    
}
