/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.service.custom.impl;

import edu.ijse.layered.dao.DaoFactory;
import edu.ijse.layered.dao.custom.TransactionsDao;
import edu.ijse.layered.dto.TransactionsDto;
import edu.ijse.layered.entity.TransactionsEntity;
import edu.ijse.layered.service.custom.TransactionsService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class TransactionsServiceImpl implements TransactionsService {
private TransactionsDao transactionsDao =(TransactionsDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.TRANSACTIONS);
    @Override
    public String save(TransactionsDto transactionsDto) throws Exception {
      TransactionsEntity entity= getTransactionsEntity(transactionsDto);
       
        return transactionsDao.create(entity) ? "Success" :"Fail";
    }
    
    @Override
    public TransactionsDto get(String TransactionID) throws Exception {
       
          TransactionsEntity entity= transactionsDao.get(TransactionID);
      if(entity!=null){
            return getTransactionsDto(entity);
        }
        return null;
    }

    @Override
    public String update(TransactionsDto transactionsDto) throws Exception {
        TransactionsEntity entity=getTransactionsEntity(transactionsDto);
       return transactionsDao.update(entity) ? "Success" :"Fail";
    }
    

    @Override
    public String delete(String TransactionID) throws Exception {
         return transactionsDao.delete(TransactionID)? "Success" :"Fail";
    }

    

    @Override
    public ArrayList<TransactionsDto> getAll() throws Exception {
          ArrayList<TransactionsEntity> transactionsEntitys=transactionsDao.getAll();
       if(transactionsEntitys != null && !transactionsEntitys.isEmpty()){
           ArrayList<TransactionsDto> transactionsDtos= new ArrayList<>();
           
           for(TransactionsEntity transactionsEntity : transactionsEntitys){
               transactionsDtos.add(getTransactionsDto(transactionsEntity));
           }
           return transactionsDtos;
       }
       return null;
    }
    
    private TransactionsEntity getTransactionsEntity(TransactionsDto transactionsDto){
       return  new TransactionsEntity( 
               transactionsDto.getTransactionID(),
                transactionsDto.getMemberID(),
                transactionsDto.getBookID(),
                transactionsDto.getBorrowDate(),
               transactionsDto.getDueDate(),
               transactionsDto.getReturnDate(),
                transactionsDto.getFineAmount());
                               
               
               }

    private TransactionsDto getTransactionsDto(TransactionsEntity entity) {
       return new TransactionsDto(
                 entity.getTransactionID(),
                  entity.getMemberID(),
                  entity.getBookID(),
                  entity.getBorrowDate(),
                 entity.getDueDate(),
                entity.getReturnDate(),
                  entity.getFineAmount() );
                 
       
       
    }
    
}
