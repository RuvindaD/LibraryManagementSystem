/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered.service.custom.impl;

import edu.ijse.layered.dao.DaoFactory;
import edu.ijse.layered.dao.custom.BooksDao;
import edu.ijse.layered.dto.BooksDto;
import edu.ijse.layered.entity.BooksEntity;
import edu.ijse.layered.service.custom.BooksService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BooksServiceImpl implements BooksService{
    
        private BooksDao booksDao =(BooksDao) DaoFactory.getInstance().getDao(DaoFactory.DaoTypes.BOOKS);

   @Override
    public BooksDto get(String BookID) throws Exception {
         BooksEntity entity= booksDao.get(BookID);
      if(entity!=null){
            return getBooksDto(entity);
        }
        return null;
    }

   
     @Override
    public String save(BooksDto booksDto) throws Exception {
          BooksEntity entity=getBooksEntity(booksDto);
        return booksDao.create(entity) ? "Success" :"Fail";
    }    

    @Override
    public String update(BooksDto booksDto) throws Exception {
        BooksEntity entity=getBooksEntity(booksDto);
        return booksDao.update(entity) ? "Success" :"Fail";
    }

    @Override
    public String delete(String BookID) throws Exception {
        return booksDao.delete(BookID)? "Success" :"Fail";
    }

    

    @Override
    public ArrayList<BooksDto> getAll() throws Exception {
        ArrayList<BooksEntity> booksEntitys=booksDao.getAll();
       if(booksEntitys != null && !booksEntitys.isEmpty()){
           ArrayList<BooksDto> booksDtos= new ArrayList<>();
           
           for(BooksEntity booksEntity : booksEntitys){
               booksDtos.add(getBooksDto(booksEntity));
           }
           return booksDtos;
       }
       return null;
    }
    
    private BooksEntity getBooksEntity(BooksDto booksDto){
       return  new BooksEntity(booksDto.getBookID(), 
                booksDto.getTitle(), 
                booksDto.getAuthor(),
               booksDto.getCategoryID(),
               booksDto.getCopiesAvailable(),
               booksDto.getPrice(),
               booksDto.getMedium(),
               booksDto.getPublisher(),
               booksDto.getFirstAuthor(),
               booksDto.getCopiesInHand());
               
               }
               

    private BooksDto getBooksDto(BooksEntity entity) {
      return new BooksDto(entity.getBookID(),
                entity.getTitle(), 
                entity.getAuthor(),
                entity.getCategoryID(),
                entity.getCopiesAvailable(),
                entity.getPrice(),
                entity.getMedium(),
                entity.getPublisher(),
                entity.getFirstAuthor(),
                entity.getCopiesInHand());
    }
    
}
    
     
    
    
