/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.ijse.layered.service.custom;

import edu.ijse.layered.dto.TransactionsDto;
import edu.ijse.layered.service.SuperService;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public interface TransactionsService extends SuperService  {
   
   String save(TransactionsDto transactionsDto) throws Exception;
   String update(TransactionsDto transactionsDto) throws Exception;
   String delete(String  MemberID) throws Exception;
   TransactionsDto get(String  MemberID)throws Exception;
   ArrayList<TransactionsDto> getAll() throws Exception;
} 

